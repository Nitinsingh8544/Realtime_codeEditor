import React from "react";


const compileBtn = () => {
    return(<>
<h1>mai hu giyan</h1>
</>
);}

export default compileBtn;